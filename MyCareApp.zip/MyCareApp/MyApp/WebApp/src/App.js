import logo from "./logo.svg";
import React from "react";
import {
  Navigate,
  Route,
  Switch,
  Routes,
  BrowserRouter as Router,
  Link,
} from "react-router-dom";

import "./pages/LoginPage/LoginPage";
import "./App.css";
import LoginPage from "./pages/LoginPage/LoginPage";
import HairdressersPage from "./pages/HairdressersPage/HairdressersPage";

function App() {
  return (
    <div className="App">
      <main>
        <Router>
          <Link to="/login">Login</Link> | <Link to="/register">Register</Link>{" "}
          | <Link to="hairdressers">Hairdressers List</Link>
          <Routes>
            <Route home path="/" element={<Navigate to="/hairdressers" />} />
            <Route
              path="/register"
              element={<span>Render Register</span>}
            ></Route>
            <Route path="/hairdressers" element={<HairdressersPage />}></Route>
            <Route path="/login" element={<LoginPage />}></Route>
          </Routes>
        </Router>
      </main>
    </div>
  );
}

export default App;
