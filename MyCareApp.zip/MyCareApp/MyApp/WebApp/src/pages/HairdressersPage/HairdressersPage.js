import React, { useState } from "react";
import axios from "axios";
import Card from "@mui/material/Card";
import "./HairdressersPage.css";

export default function HairdressersPage() {
  const [hairdressers, setHairdressers] = useState([]);
  const [loaded, setLoaded] = useState(false);

  console.log(loaded, hairdressers);

  if (!loaded) {
    axios.get("/api/hairdressers").then((response) => {
      setHairdressers(response.data);
    });
    setLoaded(true);
  }

  return (
    <div>
      {hairdressers.map((hairdresser, index) => (
        <Card key={index} className="hairdressers-card">
          <h1>
            {hairdresser.name} {hairdresser.surname}
          </h1>
          <h2>{hairdresser.email}</h2>
        </Card>
      ))}
    </div>
  );
}
