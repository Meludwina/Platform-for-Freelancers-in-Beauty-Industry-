import TextField from "@mui/material/TextField";
import Card from "@mui/material/Card";
import "./RegisterPage.css";

export default function RegisterPage() {
  return (
    <div className="main-container">
      <Card className="register-card">
        <div>
          <TextField label="Email" placeholder="example@gmail.com" /> <br />{" "}
          <br />
          <TextField type="password" label="Password" /> <br /> <br />
          <TextField type="password" label="Confirm Password" /> <br /> <br />
        </div>
      </Card>
    </div>
  );
}
