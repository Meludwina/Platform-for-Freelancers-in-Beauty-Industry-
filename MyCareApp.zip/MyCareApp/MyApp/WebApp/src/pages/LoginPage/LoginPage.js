import { useState } from "react";
import TextField from "@mui/material/TextField";
import Card from "@mui/material/Card";
import "./LoginPage.css";
import { Button } from "@mui/material";
import axios from "axios";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="main-container">
      <Card className="login-card">
        <h2>Login</h2>
        <div>
          <TextField
            label="Email"
            placeholder="example@gmail.com"
            onChange={(e) => {
              setEmail(e.target.value);
            }}
          />{" "}
          <br />
          <br />
          <TextField
            type="password"
            label="Password"
            onChange={(e) => {
              setPassword(e.target.value);
            }}
          />{" "}
          <br /> <br />
          <div className="button-container">
            <div></div>
            <div>
              <Button
                onClick={async () => {
                  console.log(email, password);

                  const response = await axios.post(
                    "http://127.0.0.1:3000/api/login",
                    {
                      email: email,
                      password: password,
                    }
                  );

                  console.log(response);
                }}
              >
                Login
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
